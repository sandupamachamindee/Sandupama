<?php



interface Damage
{
    public function damageAllData();

}